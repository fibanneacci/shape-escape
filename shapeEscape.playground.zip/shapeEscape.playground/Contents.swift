//: A SpriteKit based Playground

import PlaygroundSupport
import SpriteKit
import Foundation

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 480, height: 640))
let scene = Splash(size: CGSize(width: 480, height: 640))
scene.scaleMode = .aspectFill
sceneView.presentScene(scene)
PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
